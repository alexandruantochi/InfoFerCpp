//#ifndef DBHANDLER_H
//#define DBHANDLER_H
//#include <sqlite3.h>
//#include <string>
//
//
//class DBHandler
//{
//    public:
//        DBHandler();
//        DBHandler(const char* DBLocation);
//        void executeQuery(std::string, int client_id);
//        static int queryResolver(void *client_id, int argc, char **argv,
//                  char **azColName);
//    protected:
//
//    private:
//    sqlite3 *db;
//    int database;
//    char* errors;
//
//};
//#endif // DBHANDLER_H
