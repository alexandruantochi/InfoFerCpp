#include <iostream>
#include <map>
#include <string>
#include <fstream>
#include <vector>


int fileGenerator(int client_id, std::map<std::string, std::string> resultMap);
