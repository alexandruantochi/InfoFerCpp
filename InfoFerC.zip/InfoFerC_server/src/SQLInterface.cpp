#include "SQLInterface.h"


SQLInterface::SQLInterface()
{
hasPriority=false;
std::cout << "SQLInterface init." << std::endl;
}

